trackInfo = [
   {
      "url" : "tracks/{refseq}/simpleRepeat/trackData.json",
      "type" : "FeatureTrack",
      "label" : "simpleRepeat",
      "key" : "simpleRepeat"
   },
   {
      "url" : "tracks/{refseq}/hinv70PseudoGene/trackData.json",
      "label" : "hinv70PseudoGene",
      "type" : "FeatureTrack",
      "key" : "hinv70PseudoGene"
   },
   {
      "url" : "tracks/{refseq}/ntHumChimp/trackData.json",
      "label" : "ntHumChimp",
      "type" : "FeatureTrack",
      "key" : "ntHumChimp"
   }
]
