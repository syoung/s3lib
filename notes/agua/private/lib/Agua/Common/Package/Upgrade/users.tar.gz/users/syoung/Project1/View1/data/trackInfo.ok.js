trackInfo = 
[
   {
      "url" : "tracks/{refseq}/simpleRepeat/trackData.json",
      "label" : "simpleRepeat",
      "type" : "FeatureTrack",
      "key" : "simpleRepeat"
   },
   {
      "url" : "tracks/{refseq}/hinv70PseudoGene/trackData.json",
      "type" : "FeatureTrack",
      "label" : "hinv70PseudoGene",
      "key" : "hinv70PseudoGene"
   }
]
