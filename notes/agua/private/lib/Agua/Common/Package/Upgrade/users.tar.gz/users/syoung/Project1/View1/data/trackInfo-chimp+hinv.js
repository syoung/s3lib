trackInfo = 
[
   {
      "url" : "tracks/{refseq}/ntHumChimp/trackData.json",
      "type" : "FeatureTrack",
      "label" : "ntHumChimp",
      "key" : "ntHumChimp"
   },
   {
      "url" : "tracks/{refseq}/hinv70PseudoGene/trackData.json",
      "type" : "FeatureTrack",
      "label" : "hinv70PseudoGene",
      "key" : "hinv70PseudoGene"
   }
]
